package dao;
import factory.ConnectionFactory;
import modelo.Salas;
import java.sql.*;
import java.sql.PreparedStatement;
public class SalasDAO { 
    private Connection connection;
    Long idsalas;
    String sala;
    Long idusuario;
    public SalasDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Salas salas){ 
        String sql = "INSERT INTO salas(sala,idusuario) VALUES(?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, salas.getSala());
            stmt.setString(2, salas.getIdusuario());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
}