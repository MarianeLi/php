package dao;
import factory.ConnectionFactory;
import modelo.Espaco;
import java.sql.*;
import java.sql.PreparedStatement;
public class EspacoDAO { 
    private Connection connection;
    Long idespaco;
    String nomeespaco;
    Long idusuario;
    public EspacoDAO(){ 
        this.connection = new ConnectionFactory().getConnection();
    } 
    public void adiciona(Espaco espaco){ 
        String sql = "INSERT INTO salas(nomeespaco,idusuario) VALUES(?,?)";
        try { 
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, espaco.getNomeespaco());
            stmt.setString(2, espaco.getIdusuario());
            stmt.execute();
            stmt.close();
        } 
        catch (SQLException u) { 
            throw new RuntimeException(u);
        } 
        
    } 
    
}