package modelo;

public class Espaco {
    Long idespaco;
    String nomeespaco;
    String idusuario;

    public Long getIdespaco() {
        return idespaco;
    }
    public void setIdespaco(Long idespaco) {
        this.idespaco = idespaco;
    } 
    public String getNomeespaco() { 
        return nomeespaco;
    } 
    public void setNomeespaco(String nomeespaco) { 
        this.nomeespaco = nomeespaco;
    } 
    public String getIdusuario() { 
        return idusuario;
    } 
    public void setIdusuario(String idusuario) { 
        this.idusuario = idusuario;
    } 

}