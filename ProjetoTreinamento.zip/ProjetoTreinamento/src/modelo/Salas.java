package modelo;

public class Salas {
    Long idsala;
    String sala;
    String idusuario;

    public Long getIdsala() {
        return idsala;
    }
    public void setIdsala(Long idsala) {
        this.idsala = idsala;
    } 
    public String getSala() { 
        return sala;
    } 
    public void setSala(String sala) { 
        this.sala = sala;
    } 
    public String getIdusuario() { 
        return idusuario;
    } 
    public void setIdusuario(String idusuario) { 
        this.idusuario = idusuario;
    } 

}