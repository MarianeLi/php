package gui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;


public class TelaPrincipal extends JFrame{

    private JMenuBar menuBar = new JMenuBar();
    private JMenu menuCadastro = new JMenu("CADASTRO E PESQUISA");
    private JMenu menusai = new JMenu("SAIR");
    private JMenuItem submenuCadastra = new JMenuItem("CADASTRAR PESSOAS",new ImageIcon("fo.png"));
    private JMenuItem submenuSalas = new JMenuItem("CADASTRAR SALAS",new ImageIcon("fo.png"));
    private JMenuItem submenuEspaco = new JMenuItem("CADASTRAR ESPAÇO",new ImageIcon("fo.png"));
    private JMenuItem submenuPesquisa = new JMenuItem("PESQUISAR PESSOAS",new ImageIcon("lup.png"));
    private JMenuItem sai = new JMenuItem("SAIR DO PROGRAMA",new ImageIcon("x1.png"));


    public TelaPrincipal(){
        setSize(650,515);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Espelho de Pessoas -- Escolas SID");
        initComponents();

        submenuCadastra.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0) {
                UsuarioGUI cadastra = new UsuarioGUI();
                cadastra.setVisible(true);
            }
        });
         
        submenuSalas.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0) {
                SalasGUI salas = new SalasGUI();
                salas.setVisible(true);
            }
        });
        
        submenuEspaco.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0) {
                EspacoGUI espaco = new EspacoGUI();
                espaco.setVisible(true);
            }
        });
        submenuPesquisa.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent arg0) {
                PesquisaPessoas pesquisa = new PesquisaPessoas();
                pesquisa.setVisible(true);
            }
        });

        sai.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

    }
    private void initComponents() {
        menuCadastro.add(submenuCadastra);
        menuCadastro.addSeparator();
        menuCadastro.add(submenuSalas);
        menuCadastro.addSeparator();
        menuCadastro.add(submenuEspaco);
        menuCadastro.addSeparator();
        menuCadastro.add(submenuPesquisa);
        menuCadastro.addSeparator();
        menusai.add(sai);
        menuBar.add(menuCadastro);
        menuBar.add(menusai);
        this.setJMenuBar(menuBar);
        this.setVisible(true);
        JPanel painel = new JPanel();
        JLabel l1 = new JLabel(new ImageIcon("FundoPrincipal.jpg"));
        painel.add(l1);
        add(painel,BorderLayout.CENTER);
        menuBar.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, Color.BLACK));

    }

    public static void main(String[]args){
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }


}
