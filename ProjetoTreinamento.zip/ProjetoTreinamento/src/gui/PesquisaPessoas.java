package gui;

import dao.UsuarioDAO;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.PreparedStatement;
import static java.util.Collections.list;
import javax.swing.*;
import modelo.Usuario;


public class PesquisaPessoas extends JFrame{
    
    Usuario usuario;
    
    public PesquisaPessoas() {
        setSize(700,500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Pesquisa de Pessoa");
        initComponents();
        /*try{
            FileInputStream in = new FileInputStream("arquivo.dat");
            ObjectInputStream s = new ObjectInputStream(in);
            
        }catch(FileNotFoundException ex){
            ex.printStackTrace();
        }catch(IOException ex){
            ex.printStackTrace();
        } */  
    }
       
    private void initComponents() {
        JPanel painel = new JPanel(new GridLayout(1,4));
        JPanel painel2 = new JPanel(new GridLayout(1,3));  
        JButton bt2 = new JButton("Mostrar Pessoas");
        final JTextArea area = new JTextArea(10, 55);
        JScrollPane scrollpane = new JScrollPane(area);
        Container pane = this.getContentPane();
        area.setLineWrap(true);
        scrollpane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pane.add(scrollpane);           
        add(painel,BorderLayout.NORTH);
        add(painel2,BorderLayout.SOUTH);
        
        painel2.add(bt2);
        
         bt2.addActionListener(new ActionListener() {
            @SuppressWarnings("empty-statement")
            public void actionPerformed(ActionEvent e) {
                area.setText("");
                String str = null;
                String sql = "Select * from Usuario";
                // dao.Busca(usuario);
                //String str = usuario.setNome();
                //String str = usuario.setSobrenome();
                area.append(str);
            }
         } 
    );
    }
}
